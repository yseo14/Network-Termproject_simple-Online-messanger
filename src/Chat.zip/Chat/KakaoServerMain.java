package Chat;

public class KakaoServerMain {

	public static void main(String[] args) {
		KakaoServer kakaoServer = new KakaoServer();
		kakaoServer.openServer();
		//kakaoServer.closeServer();
	}
}
